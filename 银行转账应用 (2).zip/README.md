# Buying Gift Cards Bot boilerplate

A sample application that you can use as a boilerplate for writing bot that
would automate process of buying gift cards using crypto.

Use it at your own risk!

## Running App

1. [Create](https://test.paxful.com/list-bitcoin-buy-sell-ad) a SELL offer in gift card payment (choose "Classic Trade")
   method and memorise its offer hash (you will need it in next step)
2. Update `.env` file
3. Run `npm i` to install dependencies
4. Run `node app.js` to start the application
5. Deploy the app somewhere OR use `ngrok` (for ngrok howto see below). As a result you should have a publicly 
   accessible URL
6. Create webhook for `trade.started`, `trade.paid`, `trade.chat_message_received` events (scroll to the bottom of
   [Direct access section](https://developers.paxful.com/dashboard/direct-access)). For target URL use one that you
   got in step 4), but append to it `/paxful/webhook` suffix. So if you had `https://example.com`, then when configuring
   webhooks you should set `https://example.com/paxful/webhook`.

### Using ngrok

The application by default will be listening on http://localhost:3000, so if you haven't changed the port, then
once you have `ngrok` installed on your machine, you can run the following command to receive a publicly accessible
URL that you can use for registering as a webhook target on paxful.com:

```
ngrok http 3000
```
