const { dispatchWebhook } = require('../src/webhooks');

describe('dispatchWebhook', () => {
    let context = null;

    beforeEach(() => {
        context = {
            services: {
                paxfulApi: {
                    getTrade: jest.fn()
                },
                tradeHandler: {}
            },
            config: {}
        };
    })

    it('it must fetch data about offer only once', async () => {
        const map = {};
        const handlers = {
            'foo_event': jest.fn()
        };
        context.config.offerHashes = ['barOfferHash'];

        const req = {
            body: {
                type: 'foo_event',
                payload: {
                    trade_hash: 'fooTradeHash'
                }
            },
            context
        };

        req.context.services.paxfulApi.getTrade.mockReturnValueOnce(Promise.resolve({
            data: {
                trade: {
                    offer_hash: 'barOfferHash'
                }
            }
        }));

        await dispatchWebhook(map, handlers, req);

        expect(map['fooTradeHash']).toBeDefined();
        expect(map['fooTradeHash']).toEqual('barOfferHash');
        expect(req.context.services.paxfulApi.getTrade).toHaveBeenCalledTimes(1);
        expect(handlers.foo_event).toHaveBeenCalled();
        expect(handlers.foo_event.mock.calls[0][0]).toEqual(req.body.payload.trade_hash);
        expect(handlers.foo_event.mock.calls[0][1]).toEqual(req.context.services.paxfulApi);
        expect(handlers.foo_event.mock.calls[0][2]).toEqual(req.context.services.tradeHandler);

        await dispatchWebhook(map, handlers, req);
        expect(req.context.services.paxfulApi.getTrade).toHaveBeenCalledTimes(1);
    });

    it('handler must not be invoked if offer is not in the list of allowed offers', async () => {
        const map = {};
        const handlers = {
            'foo_event': jest.fn()
        };
        context.config.offerHashes = ['bazOfferHash'];

        const req = {
            body: {
                type: 'foo_event',
                payload: {
                    trade_hash: 'fooTradeHash'
                }
            },
            context
        };

        req.context.services.paxfulApi.getTrade.mockReturnValueOnce(Promise.resolve({
            data: {
                trade: {
                    offer_hash: 'barOfferHash'
                }
            }
        }));

        await dispatchWebhook(map, handlers, req);

        expect(handlers['foo_event']).not.toHaveBeenCalled();
    });
});