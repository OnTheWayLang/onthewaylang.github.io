const { TradeHandler, JsonFileStorage } = require('../src/trading');
const fs = require('fs');

describe("TradeHandler", function () {
    let cp = null;
    const storageFilepath = __dirname + '/storage.json';
    let paxfulApi = {};

    const readStorage = () => {
        return JSON.parse(fs.readFileSync(storageFilepath, 'binary'));
    }

    beforeEach(async () => {
        if (fs.existsSync(storageFilepath)) {
            fs.unlinkSync(storageFilepath);
        }

        cp = new TradeHandler(new JsonFileStorage(storageFilepath), paxfulApi);
    });

    it('happy path', async () => {
        const th = 'foo123';
        const cn = '1234 1234 1234 1234';

        cp.getRandomRedeemedStatus = () => { return TradeHandler.STATUS_REDEEMED; };
        paxfulApi.releaseTrade = jest.fn();

        await cp.markAsStarted(th);
        await cp.useCardForTrade(th, cn);

        expect(paxfulApi.releaseTrade).not.toHaveBeenCalled();
        await cp.redeemCardAndReleaseTrade(th, cn, null);
        expect(paxfulApi.releaseTrade).toHaveBeenCalled();

        const storage = readStorage();
        const trade = storage[th];
        expect(trade).toBeDefined();
        expect(trade.isRedeemed).toBeTruthy();
        expect(trade.cardNumber).toEqual(cn);
    });
});