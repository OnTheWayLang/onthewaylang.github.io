const express = require('express');
const { createPaxfulApi } = require('./src/api');
const { getConfig } = require('./src/config');
const { TradeHandler, JsonFileStorage } = require('./src/trading');
const webhooks = require('./src/webhooks');

const config = getConfig();
const paxfulApi = createPaxfulApi(config.clientId, config.clientSecret);
const tradeHandler = new TradeHandler(
    new JsonFileStorage(__dirname + '/storage/trades.json'),
    paxfulApi
);

let username = null;

const app = express();
app.use(async (req, res, next) => {
    req.context = {
        services: {
            paxfulApi: paxfulApi,
            tradeHandler: tradeHandler
        },
        config: { ...config, username }
    };

    next();
});
// Savings original raw body, needed for Paxful webhook signature checking
app.use(function(req, res, next) {
    req.rawBody = '';

    req.on('data', function(chunk) {
        req.rawBody += chunk;
    });

    next();
});
app.use(express.json());
app.use('/', require('./src/routes'));
app.listen(config.serverPort, async () => {
    if (!username) {
        const response = await paxfulApi.getClient().invoke('/paxful/v1/user/me');
        if (response.error) {
            // If you're getting this error, then once you have fixed it you also need to remove storage/credentials.json
            // file manually
            throw new Error(response.error_description);
        }

        username = response.data.username;
    }

    console.debug(`App listening at http://localhost:${config.serverPort}`);
});

