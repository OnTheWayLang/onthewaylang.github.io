const fs = require('fs');
const { default: usePaxful } = require("@paxful/sdk-js");

// In real word application you should consider using a database to store
// credentials
const credentialsStorage = {
    // private
    storageFilename: __dirname + '/../storage/credentials.json',

    saveCredentials(credentials) {
        fs.writeFileSync(this.storageFilename, JSON.stringify(credentials));
    },

    getCredentials() {
        return fs.existsSync(this.storageFilename) ? JSON.parse(fs.readFileSync(this.storageFilename)) : null;
    }
};

class PaxfulApiFacade {
    constructor(client) {
        this.client = client;
    }

    getClient() {
        return this.client;
    }

    async sendMessage(tradeHash, message) {
        return this.client.invoke('/paxful/v1/trade-chat/post', {
            trade_hash: tradeHash,
            message: message
        });
    }

    async tradeChatGet(tradeHash) {
        return this.client.invoke('/paxful/v1/trade-chat/get', { trade_hash: tradeHash });
    }

    async releaseTrade(tradeHash) {
        return this.client.invoke('/paxful/v1/trade/release', {
            trade_hash: tradeHash
        });
    }

    async getTrade(tradeHash) {
        return this.client.invoke('/paxful/v1/trade/get', { trade_hash: tradeHash });
    }
}

module.exports.createPaxfulApi = (clientId, clientSecret) => {
    const client = usePaxful(
        { clientId, clientSecret },
        credentialsStorage
    );
    return new PaxfulApiFacade(client);
};