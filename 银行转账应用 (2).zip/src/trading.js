const lockfile = require('proper-lockfile');
const fs = require('fs').promises;

class TradeHandler {
    static STATUS_REDEEMED = 'redeemed';
    static STATUS_INSUFFICIENT_BALANCE = 'insufficient_balance';
    static CARD_NUMBER_SAMPLE = '1111 2222 3333 4444';

    constructor(storage, paxfulApi) {
        this.storage = storage;
        this.paxfulApi = paxfulApi;
    }

    containsCardNumber(text) {
        return /\d{4}\s\d{4}\s\d{4}\s\d{4}/.test(text);
    }

    extractCardNumber(text) {
        const result = /(\d{4}\s\d{4}\s\d{4}\s\d{4})/g.exec(text);

        return result !== null ? result[0] : null;
    }

    async hasEnoughBalance(cardNumber, expectedValue) {
        // TODO a stub, implement real card balance validation logic
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const hasEnoughBalance = this.getRandomIsEnoughBalance();
                resolve(hasEnoughBalance);
            }, 2000)
        });
    }

    // private
    getRandomRedeemedStatus() {
        return Math.random() > 0.3 ? TradeHandler.STATUS_REDEEMED : TradeHandler.STATUS_INSUFFICIENT_BALANCE;
    }

    // private
    getRandomIsEnoughBalance() {
        return Math.random() > 0.3;
    }

    // private
    async doRedeemCard(tradeHash, cardNumber, valueToRedeem) {
        // TODO a stub, implement real card redeeming logic
        return Promise.resolve(this.getRandomRedeemedStatus());
    }

    async redeemCardAndReleaseTrade (tradeHash, cardNumber, valueToRedeem) {
        const status = await this.doRedeemCard(tradeHash, cardNumber, valueToRedeem);

        if (status === TradeHandler.STATUS_REDEEMED) {
            await this.storage.updateTrade(tradeHash, (trade) => {
                trade.isRedeemed = true;
                trade.redeemedAmount = valueToRedeem;

                this.paxfulApi.releaseTrade(tradeHash);

                return trade;
            });
        }

        return status;
    }

    async markAsStarted(tradeHash) {
        const trade = await this.storage.getTrade(tradeHash);
        if (!trade) {
            await this.storage.saveTrade(tradeHash, {
                cardNumber: null,
                isRedeemed: false,
                redeemedAmount: 0
            });
        } else {
            throw new Error('You can mark a trade as started only once.');
        }
    }

    async getTradeCard(tradeHash) {
        return (await this.storage.getTrade(tradeHash)).cardNumber;
    }

    async useCardForTrade(tradeHash, cardNumber) {
        if (!(await this.storage.getTrade(tradeHash))) {
            throw new Error(`Trade "${tradeHash}" hasn't yet been marked as started.`);
        }

        await this.storage.updateTrade(tradeHash, (trade) => {
            trade.cardNumber = cardNumber;

            return trade;
        });
    }
}

// Here we're relying on storing data in a JSON file. For a production use please re-implement to use
// database
class JsonFileStorage {
    constructor(storageFilename) {
        this.storageFilename = storageFilename;
    }

    async getTrades() {
        if (!require('fs').existsSync(this.storageFilename)) {
            await fs.writeFile(this.storageFilename, JSON.stringify({}));
        }

        return await JSON.parse(await fs.readFile(this.storageFilename, 'binary'));
    }

    async getTrade(tradeHash) {
        return (await this.getTrades())[tradeHash];
    }

    async updateTrade(tradeHash, operation) {
        try {
            await lockfile.lock(this.storageFilename);
            const trades = await this.getTrades();

            if (!trades[tradeHash]) {
                throw new Error(`No trade found with trade hash - '${tradeHash}'.`);
            }
            const trade = trades[tradeHash];

            const updatedTrade = await operation(trade);
            if (!updatedTrade) {
                throw new Error('Updated trade cannot be empty.');
            }
            trades[tradeHash] = updatedTrade;

            await fs.writeFile(this.storageFilename, JSON.stringify(trades, null, 2));
        } finally {
            await lockfile.unlock(this.storageFilename);
        }
    }

    async saveTrade(id, trade) {
        await lockfile.lock(this.storageFilename);
        const trades = await this.getTrades();
        trades[id] = trade;
        await fs.writeFile(this.storageFilename, JSON.stringify(trades, null, 2));
        await lockfile.unlock(this.storageFilename);
    }
}

module.exports.JsonFileStorage = JsonFileStorage;
module.exports.TradeHandler = TradeHandler;
