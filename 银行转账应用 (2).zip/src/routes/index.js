const express = require('express');
const { isValidSignature, dispatchWebhook } = require('../webhooks');
const { TradeHandler } = require('../trading');

const router = express.Router();

const sleep = async (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

const handlers = {
    'trade.started': async (tradeHash, paxfulApi, tradeHandler) => {
        await tradeHandler.markAsStarted(tradeHash);

        await paxfulApi.sendMessage(
            tradeHash,
            `This is a fully automated trade.\nPlease share a gift card number in the following format: ${TradeHandler.CARD_NUMBER_SAMPLE}`
        );
    },
    'trade.chat_message_received': async (tradeHash, paxfulApi, tradeHandler, config) => {
        const trade = (await paxfulApi.getTrade(tradeHash)).data.trade;
        const tradeStatus = trade.trade_status.toLowerCase();

        if (!['active funded', 'paid'].includes(tradeStatus)) {
            return;
        }

        const allMessages = (await paxfulApi.tradeChatGet(tradeHash)).data.messages;
        const nonSystemMessages = allMessages.filter(m => 'msg' === m.type).reverse();
        const sellerMessages = nonSystemMessages.filter((msg) => msg.author !== config.username);

        const lastNonSystemMessage = nonSystemMessages.slice()[0];
        const isLastMessageBySeller = lastNonSystemMessage.author !== config.username;
        if (!isLastMessageBySeller) {
            return;
        }

        const cardNumber = tradeHandler.extractCardNumber(sellerMessages[0].text);
        if (cardNumber) {
            await tradeHandler.useCardForTrade(tradeHash, cardNumber);

            switch (tradeStatus) {
                case 'active funded':
                    await paxfulApi.sendMessage(
                        tradeHash,
                        `Verifying balance of card ${cardNumber}. Please wait, that might take a few seconds.`
                    );

                    if (await tradeHandler.hasEnoughBalance(cardNumber, trade.fiat_amount_requested)) {
                        await paxfulApi.sendMessage(
                            tradeHash,
                            'Great, card has enough balance. Please mark trade as paid and then we will redeem it.'
                        );
                    } else {
                        await paxfulApi.sendMessage(
                            tradeHash,
                            `Card ${cardNumber} doesn't have enough balance, please send a new card and we will try again.`
                        );
                    }
                    break;

                case 'paid':
                    await handlers['trade.paid'](tradeHash, paxfulApi, tradeHandler, config);
                    break;
            }
        } else {
            const currentlyUsedCardNumber = await tradeHandler.getTradeCard(tradeHash);

            let message;
            if (currentlyUsedCardNumber) {
                message = [
                    'We were unable to understand your previous message',
                    'If you would like to use another card for this trade, please just share its number'
                ];
            } else {
                message = [
                    'We were unable to understand your previous message',
                    `Please share a gift card number in the following format: ${TradeHandler.CARD_NUMBER_SAMPLE}`
                ];
            }

            await paxfulApi.sendMessage(tradeHash, message.join(".\n"));
        }
    },
    'trade.paid': async (tradeHash, paxfulApi, tradeHandler) => {
        const cardNumber = await tradeHandler.getTradeCard(tradeHash);
        const trade = (await paxfulApi.getTrade(tradeHash)).data.trade;

        if (cardNumber) {
            const status = await tradeHandler.redeemCardAndReleaseTrade(tradeHash, cardNumber, trade.fiat_amount_requested);

            // This will help with having a chat message delivered after
            // a notice that crypto has been released
            await sleep(2000);

            switch (status) {
                case TradeHandler.STATUS_INSUFFICIENT_BALANCE:
                    await paxfulApi.sendMessage(
                        tradeHash,
                        `Card ${cardNumber} doesn't have enough balance, please send another card number.`
                    );
                    break;
                case TradeHandler.STATUS_REDEEMED:
                    await paxfulApi.sendMessage(
                        tradeHash,
                        `Card ${cardNumber} has been redeemed, great doing business with you!`
                    );
                    break;
            }
        } else {
            await paxfulApi.sendMessage(
                tradeHash,
                `Please share a valid card number before marking a trade as paid.`
            );
        }
    }
}

// No problem keeping to have it in-memory. Even if process is restarted we can easily rebuild it
const tradeToOfferMap = {};

router.post('/paxful/webhook', async (req, res) => {
    res.set("X-Paxful-Request-Challenge", req.headers['x-paxful-request-challenge'])

    const isValidationRequest = req.body.type === undefined;
    if (isValidationRequest) {
        console.debug("Validation request arrived");

        res.json({"status": "ok"});
        return
    }

    const signature = req.get('x-paxful-signature');
    if (!signature) {
        console.warn("No signature");

        res.json({"status": "error", "message": "No signature header"});
        res.status(403);
        return;
    }

    if (!isValidSignature(signature, req.get('host'), req.originalUrl, req.rawBody)) {
        console.warn("Invalid signature");

        res.json({"status": "error", "message": "Invalid signature"});
        res.status(403);
        return;
    }

    console.debug("\n---------------------")
    console.debug("New incoming webhook:")
    console.debug(req.body)
    console.debug("---------------------")

    try {
        await dispatchWebhook(tradeToOfferMap, handlers, req);
        res.json({ success: true });
    } catch (e) {
        res.json({ success: false });
    }
});

module.exports = router;