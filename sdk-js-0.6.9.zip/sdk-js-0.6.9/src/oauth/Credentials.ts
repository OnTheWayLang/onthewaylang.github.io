export type Credentials = {
    accessToken: string;
    refreshToken: string;
    expiresAt: Date;
}
